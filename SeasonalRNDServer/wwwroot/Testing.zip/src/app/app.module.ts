import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ButtonModule } from "primeng/button";
import { SplitterModule } from "primeng/splitter";
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { HttpClientModule} from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    TestComponent
  ],
  imports: [
    BrowserModule,ButtonModule,SplitterModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [TestComponent]
})
export class AppModule { }
